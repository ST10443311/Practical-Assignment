
package progicetask2;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ProgIceTask2 {
    
    public enum Months{
        January, February, March, April, May, June, July, August, September, October, November, December
    }
    
    public static void main(String[] args) {
        
        int noStudents;
        String firstName;
        String lastName;
        String studentNo;
        Months birthMonth;
        int age;
        int noModules;
        int costPerModule;
        
        noStudents = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the number of students registered"));
        
        ArrayList<String> lastNames = new ArrayList<>();
        ArrayList<Student> students = new ArrayList<>();
        
        for(int i = 0; i < noStudents; i++){
        
            firstName = JOptionPane.showInputDialog(null,"Enter the first name");
            lastName = JOptionPane.showInputDialog(null,"Enter the last name");
            lastNames.add(lastName);
            studentNo = JOptionPane.showInputDialog(null,"Enter the student number");
            birthMonth = Months.valueOf(JOptionPane.showInputDialog(null,"Enter the birth month"));
            age = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the age"));
            noModules = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the number of modules"));
            costPerModule = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the cost per module"));
        
            Student student = new Student(firstName, lastName, studentNo, birthMonth, age, noModules, costPerModule);
            students.add(student);
        
        } 
        
 
        for(int i = 0; i < lastNames.size(); i++){
            if(lastNames.get(i).charAt(0) < lastNames.get(i+1).charAt(0)){
                
                String temporary = lastNames.get(i+1);
                lastNames.set(i+1, lastNames.get(i));
                lastNames.set(i, temporary);
                
                Student temp = students.get(i+1);
                students.set(i+1, students.get(i));
                students.set(i, temp);
                
            }
        }
        
        //Final output
        display(students);
        
    }   
    
    public static void display(ArrayList<Student> students){
    
        for(int y = 0; y < students.size(); y++){
            
            JOptionPane.showMessageDialog(null,
            "\nPERSONAL INFO\nFirst name: " + students.get(y).getFirstName() + 
            "\nLast name: " + students.get(y).getLastName() + 
            "\nStudent number: " + students.get(y).getStudentNo() + 
            "\nBirth month: " + students.get(y).getBirthMonth() + 
            "\nAge: " + students.get(y).getAge() + 
            "\n\nMODULES\nNumber of modules: " + students.get(y).getNoModules() + 
            "\nCost per modules: " + students.get(y).getCostPerModule()
            );
            
            /*System.out.println(
            "\nPERSONAL INFO\nFirst name: " + firstName + 
            "\nLast name: " + lastName + 
            "\nStudent number: " + studentNo + 
            "\nBirth month: " + birthMonth + 
            "\nAge: " + age + 
            "\n\nMODULES\nNumber of modules: " + noModules + 
            "\nCost per modules: " + costPerModule
            );
            */
        }
    }
    
}
