
package progicetask2;

import progicetask2.ProgIceTask2.Months;
import javax.swing.JOptionPane;

public class Student {
    
    private String firstName;
    private String lastName;
    private String studentNo;
    private final Months birthMonth;
    private int age;
    private int noModules;
    private double costPerModule;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getStudentNo() {
        return studentNo;
    }

    public Months getBirthMonth() {
        return birthMonth;
    }

    public int getAge() {
        return age;
    }

    public int getNoModules() {
        return noModules;
    }

    public double getCostPerModule() {
        return costPerModule;
    }
    
    
    Student(String firstName, String lastName, String studentNo, Months birthMonth, int age, int noModules, int costPerModule){
        this.firstName = firstName;
        this.lastName = lastName;
        this.lastName = lastName;
        this.birthMonth = birthMonth;
        this.age = age;
        this.noModules = noModules;
        this.costPerModule = costPerModule;
    }
    
    public static double calcTotal(int noModules, double costPerModule){
        double total;
        double discount = 0; 
        
        total = noModules * costPerModule;
        
        int choice = Integer.parseInt(JOptionPane.showInputDialog("Select your method of payment:\n\n1) Cash (20% discount)\n2) Two Parts (10% discount)\n3) Neither (No discount)"));
        if(choice == 1){
            discount = total * 0.2;
        }else if(choice == 2){
            discount = total * 0.1;
        }
        
        total = total - discount;
        
        return total;
    }
    
}
