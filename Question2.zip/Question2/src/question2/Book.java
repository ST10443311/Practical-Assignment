
package question2;

class Book extends LibraryItem {
    private String bookNum;

    public Book(String title, String author, String bookNum) {
        super(title, author);
        this.bookNum = bookNum;
    }

    public String getbookNum() {
        return bookNum;
    }
}

