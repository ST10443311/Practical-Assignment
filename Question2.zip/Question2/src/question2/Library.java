
package question2;

import java.util.ArrayList;

class Library {
    private ArrayList<Book> books;

    public Library() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void borrowBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title) && !book.isBorrowed()) {
                book.borrowItem();
                System.out.println("You borrowed \"" + book.getTitle() + "\".");
                return;
            }
        }
        System.out.println("The book \"" + title + "\" is either not available or already borrowed.");
    }

    public void returnBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title) && book.isBorrowed()) {
                book.returnItem();
                System.out.println("You returned \"" + book.getTitle() + "\".");
                return;
            }
        }
        System.out.println("The book \"" + title + "\" was not borrowed from this library.");
    }

    public void printInventory() {
        System.out.println("Library Inventory:");
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor() +
                    ", bookNum: " + book.getbookNum() + ", Borrowed: " + book.isBorrowed());
        }
    }
}
