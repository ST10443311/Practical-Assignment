
package question2;

import org.junit.Test;
import static org.junit.Assert.*;

public class LibraryTest {
    
    public LibraryTest() {
    }

    @Test
    public void testAddBook() {
    }

    @Test
    public void testBorrowBook() {
    }

    @Test
    public void testReturnBook() {
    }

    @Test
    public void testPrintInventory() {
    }
    
}
